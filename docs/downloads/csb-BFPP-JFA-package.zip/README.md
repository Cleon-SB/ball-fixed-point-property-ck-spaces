# Artigo reescrito para o Journal of Functional Analysis

Nova versão separada; o arquivo do OneDrive não foi alterado.

## Arquivos

- `csb-BFPP-JFA.tex`: artigo completo em inglês, fonte autônomo.
- `csb-BFPP-JFA.pdf`: PDF de 21 páginas, compilado e inspecionado visualmente.
- `analise-lema-A1.md`: análise de dependências que fundamenta a retirada do antigo apêndice em 14/09/2026.
- `analise-revisao-booleana.md`: comparação com a versão estética do autor, compatibilidade Lean, motivações e preliminares booleanos.
- `analise-critica.md`: parecer sobre título, abstract, introdução, organização e demonstrações; cobertura das 1.067 linhas originais em 95 blocos contíguos.
- `auditoria-linha-a-linha.csv`: uma entrada para cada linha original.
- `alteracoes.patch`: diferenças entre o original e a versão JFA.
- `csb-BFPP-original.tex`: cópia integral do original para consulta e comparação.
- `csb-BFPP-JFA-package.zip`: fonte, PDF e este README. O parecer e a cópia original ficam fora desse pacote.

## Compilação

A partir da pasta que contém o fonte:

```text
pdflatex -interaction=nonstopmode -halt-on-error csb-BFPP-JFA.tex
pdflatex -interaction=nonstopmode -halt-on-error csb-BFPP-JFA.tex
```

Não é necessário BibTeX: as referências estão no próprio fonte. A classe `elsarticle` e os pacotes utilizados integram distribuições TeX usuais. A compilação foi conferida com TeX Live 2022, pdfLaTeX e elsarticle 3.3.

Conferência da revisão editorial mais recente de 14/09/2026: 21 páginas, 57 rótulos únicos, 49 chamadas de referência cruzada, quatro referências bibliográficas citadas. Nenhum erro, aviso de compilação, referência indefinida, overfull box ou underfull box no log final. Todas as páginas foram renderizadas e inspecionadas.

O antigo apêndice (Lema A.1 e Observação A.2) foi retirado por não ser utilizado em nenhuma prova do corpo do artigo. Foram ajustadas somente as duas menções explicativas, na introdução e na observação final. Os enunciados, provas e números dos resultados principais permanecem inalterados. O parecer inicial e a auditoria do original são registros históricos; a decisão posterior sobre o apêndice está em `analise-lema-A1.md`. A formalização Lean conserva o antigo apêndice como material suplementar, com documentação atualizada.

## Dados a completar pelo autor

Afiliação, e-mail, declaração de assistência por IA e o status “To appear in arXiv” da referência Barroso2026 foram incorporados da versão fornecida pelo autor em 14/09/2026. O identificador público dessa referência poderá ser acrescentado quando estiver disponível. O agradecimento a referee continua comentado, como no arquivo do autor. A cópia de origem no OneDrive não foi alterada.

## Revisão de motivação e preliminares

Foram inseridas frases explicativas antes do Lema 4.2 e das Proposições 4.3 e 4.4, além de dois parágrafos de terminologia booleana no início da Subseção 4.2 e da referência a Koppelberg. A referência específica a Monk permanece na prova do Lema 4.2. A divisão de equações feita pelo autor foi preservada; o segundo rótulo duplicado `tcp:eq:encoded-maps` passou a `tcp:eq:encoded-synthesis-propagator`. Os números dos resultados são os mesmos. A documentação Lean identifica o novo manuscrito, mantendo os arquivos de prova e o registro histórico de verificação.

## Formato editorial

Foi adotado o formato de manuscrito `elsarticle` (preprint, 12 pt), com front matter, palavras-chave, MSC 2020, referências numéricas e numeração por seção. Base: [instruções oficiais de LaTeX da Elsevier](https://www.elsevier.com/researcher/author/policies-and-guidelines/latex-instructions).

O [guia específico do JFA](https://www.sciencedirect.com/journal/journal-of-functional-analysis/publish/guide-for-authors) retornou HTTP 403 durante a consulta. Não se presume a verificação de exigências adicionais do portal nem se apresenta esta cópia como prova tipográfica de artigo aceito.
