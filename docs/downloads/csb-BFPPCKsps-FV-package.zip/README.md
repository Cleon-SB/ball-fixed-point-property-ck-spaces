# Final manuscript and companion formalization

Title: Transfinite contractive propagation and the ball fixed point property in C(K)
Author: Cleon S. Barroso
Version synchronized on 14 September 2026.

## Files

- `csb-BFPPCKsps-FV.tex`: the author's final LaTeX source (928 lines).
- `csb-BFPPCKsps-FV.pdf`: the matching 21-page PDF, compiled with pdfLaTeX.

Source SHA-256: `feefe0f1af582753d5b22ada4baa01e87b1c1533706f47cd02d4c3c1b8ddc5ca`.

## Compilation

```text
pdflatex -interaction=nonstopmode -halt-on-error csb-BFPPCKsps-FV.tex
pdflatex -interaction=nonstopmode -halt-on-error csb-BFPPCKsps-FV.tex
```

The bibliography is embedded in the source; BibTeX is not needed.
Compilation was checked with TeX Live 2022, pdfLaTeX, and elsarticle 3.3.
The final log contains no compilation warnings or undefined references.

## Lean companion

The companion repository is
https://github.com/Cleon-SB/ball-fixed-point-property-ck-spaces

Its COVERAGE.md identifies this source and maps the mathematical results to
Lean declarations. VALIDATION.md preserves the historical verification record
and distinguishes later editorial changes from Lean compilation.

This version adds the author's Lean formalization paragraph, including
"is available at", and uses the author's requested final filename. All 38
statement/proof environments are identical modulo whitespace to the previous
918-line manuscript. No Lean proof files or dependency versions were changed.
Preparing this package does not publish or change access to the repository.
